<?php   //creating connection
    $dbhost = "182.50.133.173";
    $dbuser = "studDB21a";
    $dbpass = "stud21DB1!";
    $dbname = "studDB21a";

    $connection = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    //echo "connection to DB success";

    //testing connection success
    if(mysqli_connect_errno()) {
        die("DB connection failed: " . mysqli_connect_error() . " (" . mysqli_connect_errno() . ")");
    }