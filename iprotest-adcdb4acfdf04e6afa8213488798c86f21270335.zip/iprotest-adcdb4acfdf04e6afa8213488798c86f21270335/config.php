<?
define ("URL", "http://localhost/iprotest/");